<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://theo-armour.github.io/qdata/apps/notes "View file as a web page." ) </span>

<div><input type=button onclick=window.location.href="https://github.com/theo-armour/qdata/tree/master/docs/apps/notes";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [tNotes Read Me]( #README.md )

<!--@@@
<iframe src=https://https://theo-armour.github.io/qdata/xxxxxx/xxxxxx.html width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_basic-html.html_
@@@-->

### Full Screen: [tNotes]( https://https://theo-armour.github.io/qdata/apps/notes )


<details open >
<summary>Concept</summary>

Realtime note-taking available on all your devices


</details>

<details open >
<summary>To do and wish list </summary>

* Make 100% JavaScript - so can work in trayo nicely


</details>

<details open >
<summary>Issues </summary>


</details>

<details open >
<summary> Things you can do using this script</summary>

* Click the three bars( 'hamburger menu icon' ) to slide the menu in and out
* Click the GitHub Octocat icon to view or edit the source code on GitHub
* Click on title to reload te page
* Press Control-U/Command-Option-U to view the source code
* Press Control-Shift-J/Command-Option-J to see if the JavaScript console reports any errors

</details>

<details open >
<summary>Links of interest</summary>


</details>

<details open >
<summary>Change log </summary>

### 123

* First commit

</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > ❦ </a></center>
