<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://theo-armour.github.io/qdata/ "View file as a web page." ) </span>

<div><input type=button onclick="window.location.href='https://github.com/theo-armour/qdata/blob/master/docs/apps'";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Apps Read Me]( #README.md )


<details open >
<summary>Concept</summary>


</details>

<details open >
<summary>To do and wish list </summary>


</details>

<details open >
<summary>Issues </summary>


</details>


<details open >
<summary>Links of interest</summary>

###  [new tab]( https://theo-armour.github.io/qdata/apps/new-tab/ )
###  [notes dark]( https://theo-armour.github.io/qdata/apps/notes-dark/ )

</details>

<details open >
<summary>Change log </summary>

### 2020-01-13

* First commit

</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > ❦ </a></center>
