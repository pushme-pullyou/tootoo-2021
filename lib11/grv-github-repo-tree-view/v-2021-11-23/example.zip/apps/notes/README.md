<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://theo-armour.github.io/qdata/apps/notes "View file as a web page." ) </span>

<div><input type=button onclick=window.location.href="https://github.com/theo-armour/qdata/tree/master/docs/apps/notes";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [tNotes Read Me]( #README.md )

<!--@@@
<iframe src=https://https://theo-armour.github.io/qdata/xxxxxx/xxxxxx.html width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_basic-html.html_
@@@-->

### Full Screen: [tNotes]( https://https://theo-armour.github.io/qdata/apps/notes )


<details open >
<summary>Concept</summary>

Realtime note-taking available on all your devices


</details>


<details open >
<summary>Issues </summary>


</details>

## To do

* 2021-02-15 ~ Control-S to save
* Multiple text areas
* Save to local storage
* Make 100% JavaScript - so can work in trayo nicely

## Change log

### 2021-02-18

* Put everything into HTML file
* Alt-S to save
* Message if exit without save


### 2021-02-15

* new tNotes

### 2020-05-18


* First commit

</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > ❦ </a></center>
