# Text Editor Theo Read Me

<div style=height:510px;width:100%;resize:both; ><iframe src="https://theo-armour.github.io/qdata/apps/text-editor/" style=height:100%;width:100%; ></iframe></div>

## Full screen: [ Text Editor Theo ]( https://theo-armour.github.io/qdata/apps/text-editor/ )

## Wish list

* Format HTML
* Add insert image? Other Midas commands?

## Links

* https://www-archive.mozilla.org/editor/midasdemo/
* https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Editable_content
* https://developer.mozilla.org/en-US/docs/Mozilla/Projects/Midas

***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>