<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://ladybug.tools/spider-covid-19-viz-3d/readme.html#assets/0-templates/README.md "View file as a web page." ) </span>

<div><input type=button class = 'btn btn-secondary btn-sm' onclick=window.location.href="https://github.com/ladybug-tools/spider-covid-19-viz-3d/tree/master/xxxxxx/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Assets Icons Read Me]( https://ladybug.tools/spider-covid-19-viz-3d/readme.html#assets/icons/README.md )

<!--
<iframe src=https://ladybug.tools/spider-covid-19-viz-3d/xxxxxx/ width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_basic-html.html_

### Full Screen: [ZZZZZ]( https://www.ladybug.tools/spider-covid-19-viz-3d/xxxxxx/ )
-->

<details open >
<summary>Credits</summary>

* noun_Globe_2117848.svg ~ Globe by Markus from the Noun Project
* noun_Home_3359355.svg ~ Home by Arvelio2001 from the Noun Project 
* noun_Information_585560.svg ~ Information by Delwar Hossain from the Noun Project
* noun_Pencil_2995943.svg ~ Pencil by shuai tawf from the Noun Project



</details>

<details open >
<summary>To do and wish list </summary>


</details>

<details open >
<summary>Issues </summary>


</details>

<details open >
<summary>Links of interest</summary>


</details>

<details open >
<summary>Change log </summary>

### 123

* First commit

</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > <img src="../../assets/spider.ico" height=24 > </a></center>
