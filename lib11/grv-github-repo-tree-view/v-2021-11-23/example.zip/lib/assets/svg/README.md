# SVG

## Creators

* https://news.ycombinator.com/item?id=26036719
* https://www.softr.io/tools/svg-shape-generator