# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [FOX File Open XHR Read Me]( https://pushme-pullyou.github.io/tootoo-2021/lib-templates/readme.html#lib/fox-file-open-xhr/README.md)


<!--@@@
<div class=ifrResize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/lib/fox-file-open-xhr/ height=100% width=100% ></iframe></div>
_FOX File Open XHR in a resizable window. One finger to rotate. Two to zoom._

### Full Screen: [FOX File Open XHR]( https://pushme-pullyou.github.io/tootoo-2021/lib/fox-file-open-xhr/ )
@@@-->


## Concept


## To Do / Wish List

* Better handling of images
* Center small images?

## Issues


## Links of Interest

* https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest
* https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest
* https://en.wikipedia.org/wiki/XMLHttpRequest


## Change Log

### 2021-07-01

* update readme
* Update html
* js: cleanup & jsHint

### 2021-06-15

* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
