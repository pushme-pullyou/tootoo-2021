# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [MNU menu Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#lib/mnu-menu/README.md)



<!--
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/lib/mnu-menu/ height=100% width=100% ></iframe></div>
_mnu-menu.html_
-->

### Full Screen: [MNU Menu]( https://pushme-pullyou.github.io/tootoo-2021/lib/mnu-menu/ )


## Concept

``` js

${ MNU.addInfoBox( "Files to try" ) }

```

## To Do / Wish List

* 2021-08-17 ~ All items in the JavaScript to have a demo or test
* 2021-07-04 ~ Add test menu with links to readme files
* Search
* Context menu
* Cursor keys select items ~ tab key?
* InfoBox easier to enter
* MNU popUp hide

## Issues

* Darkmode broken
* Popup not used

## Links of Interest


## Change Log

### 2021-08-17

* Fix index.html
* update readme


### 2021-07-??

* Add ID to infobox

### 2021-06-29

* Many fixes

### 2021-06-27

* First commit

***

<center><a href=javascript:window.main.scrollTo(0,0); class=aDingbat title="Scroll to top" > ❦ </a></center>
