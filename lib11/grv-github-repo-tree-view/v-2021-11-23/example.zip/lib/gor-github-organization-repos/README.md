# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )]( https://github.com/pushme-pullyou/tootoo-2021/tree/main/lib/gor-github-organization-repos/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [GOR GitHub Organization Repos Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#lib/gor-github-organization-repos/README.md )


<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/ lib/gor-github-organization-repos/ height=100% width=100% ></iframe></div>
_gor-github-organization-repos in a resizable window. One finger to rotate. Two to zoom._

### Full Screen: [gor-github-organization-repos]( https://pushme-pullyou.github.io/tootoo-2021/lib/gor-github-organization-repos/ )
@@@-->


## Concept


## To Do / Wish List

* 2021-07-03 ~ Improve the documentation
* 2021-07-03 ~ update user & repo using location hash

## Issues


## Links of Interest


## Change Log

### 2021-07-03

* Update readme.html & .md

### 2020-12-27

* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
