# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/tree/main/lib/style "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [Style Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#lib/style/README.md)


## Concept


## To Do / Wish List

* 2021-07-08 ~ better tree view classes

## Issues


## Links of Interest

Add rules to existing style sheet

* https://usefulangle.com/post/39/adding-css-to-stylesheet-with-javascript#:~:text=You%20can%20insert%20a%20new,rule%20to%20the%20stylesheet%20sheet.



Web

* https://github.com/dohliam/dropin-minimal-css
* https://www.w3schools.com/w3css/
    * https://www.w3schools.com/w3css/w3css_colors.asp
    * https://www.w3schools.com/lib/w3-theme-red.css
* https://bootswatch.com/

Switching themes

* https://github.com/Mohammad-Farmaan/Dark-Mode-For-Web


## Change Log

### 2021-07-08

* Add class summary tertiary

### 2020-09-17

* Cleanup

### 2020-07-05

* First commit


***

<center title="hello! Click me to go up to the top" ><a href=javascript:window.main.scrollTo(0,0); class=aDingbat > ❦ </a></center>

