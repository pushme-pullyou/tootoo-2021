<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( http://jaanga.github.io/xxxxxx/#README.md "View file as a web page." ) </span>

<div><input type=button class = 'btn btn-secondary btn-sm' onclick=window.location.href='https://github.com/jaanga/000000/tree/master/documents/xxxxxx/';
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>

[Jaanga]( https://jaanga.github.io ) &raquo; [ oooooo ]( http://jaanga.github.io/documents/  ) &raquo;


[XXXXXX Read Me]( https://jaanga.github.io/xxxxxx/index.html#readme.md )
===
_say something fun_

## Full Screen: [ XXXXXX ]( https://jaanga.github.io/xxxxxx/index.html )

<img src="" style=display:none; width=800 >


<div style="border: 1px solid red; display:none;" ><iframe src=https://jaanga.github.io/documents/xxxxxx/index.html width=100% height=600px onload=this.contentWindow.controls.enableZoom=false; >Iframes are not viewable in GitHub source code views</iframe></div>

_XXXXXX_

***

## Concept

### Issues / Problems
<!--

The general format is an adaptation of the ideas developed in Alexander's _et al_ [A Pattern Language]( https://books.google.com/books?id=hwAHmktpk5IC&pg=PR10#v=onepage&q&f=false ) - as summarized on page 10.

Each pattern describes a problem which occurs over and over again in our environment, and then describes the core of the solution to that problem, in such a way that you can use this solution a million times over, without ever doing it the same way twice.

patterns are descriptions of common problems and proposal for the solutions that can be used repeatedly every time the problem is encountered and producing an different outcome.

-->

### Mission
<!-- a statement of a rationale, applicable now as well as in the future -->

* TBD

### Vision
<!--  a descriptive picture of a desired future state -->

* TBD

## To Do / Goals / Up Next



## Issues / Bugs / Things that need Work


## Features

* TBD
* Click three bars( 'hamburger' ) icon to slide menu in or out
* Direct link to this read me file
* Click on title to reload


## Things you can do using this script


* Click the three bars( 'hamburger menu icon' ) to slide the menu in and out
* Press Control-U/Command-Option-U to view the source code
* Press Control-Shift-J/Command-Option-J to see if the JavaScript console reports any errors



## Things you can do by editing the code

<iframe src='https://jaanga.github.io/cookbook-html/examples/libraries/ace-editor/ace-view-r1.html#
	http://jaanga.github.io/documents/xxxxxx/xxxxxx-r1.html' width=100% height=600 ></iframe>

<input type=button onclick=window.location.href='https://github.com/jaanga/jaanga.github.io/tree/master/documents/xxxxxx/xxxxxx-r1.html';
value='Source code listing' >


* Open this file: https://github.com/jaanga/jaanga.github.io/tree/master/documents/xxxxxx/xxxxxx-r1.html
* Click the 'Raw' icon and save the raw file to your computer
* Once you've downloaded the file, you can click it to run it.
* Open the file with a text editor


<!--
## Users
_where used_

Intended for xxx
-->



## Links of Interest



## Change Log

###

* First commit
* Add Read Me


***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > ❦ </a></center>

