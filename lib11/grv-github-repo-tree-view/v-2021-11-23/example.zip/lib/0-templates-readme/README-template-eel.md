# [Template Read Me]( ./readme.html )

<!--@@@
<div style=height:300px;overflow:hidden;width:100%;resize:both; ><iframe src=https://evereverland.github.io/lib/style/ height=100% width=100% ></iframe></div>
_Spider /lib/style_

### Full Screen: [/lib/style]( https://evereverland.github.io/lib/style/ )
@@@-->


## Concept


## To Do / Wish List


## Issues


## Links of Interest


## Change Log

### 2020-11-11


***

<center title="You have reached the end of the line" ><a title="Return to top" href="javascript:window.scrollTo(0,0);" class=aDingbat > ❧ </a></center>

