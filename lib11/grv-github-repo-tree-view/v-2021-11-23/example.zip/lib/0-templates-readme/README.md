
<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://pushme-pullyou.github.io/templates-01/open-markdown-or-html/readme.html "View file as a web page." ) </span>

<div><input type=button onclick=window.location.href="https://github.com/pushme-pullyou/templates-01/tree/master/open-markdown-or-html"
value="You are now in a GitHub web page view - Click this button to view this read me file as source code" ></div>


# [Templates Read Me]( ./readme.html )

<!--@@@
<div class=iframe-resize title="Resize me">
<iframe src=https://pushme-pullyou.github.io/templates-01/open-markdown-or-html/readme.html width=100% height=100% ></iframe></div>
_<small>open-markdown-or-html</small>_
@@@-->

## Full Screen: [open-markdown-or-html]( https://pushme-pullyou.github.io/templates-01/open-markdown-or-html/readme.html )

## [markdown-help.md]( #../assets/markdown-help.md )
## [assets/style.css]( #../assets/style.css )


## Concept

File wrangler.

Default index.html file. Opens HTML or Markdown files. Passes location.hash.

Uses [showdown.js]( https://github.com/showdownjs/showdown ) to convert markdown to HTML

## To Do / Wish List


## Issues



## Links of Interest

* https://github.com/pushme-pullyou/templates-01/tree/master/html-hamburger-plus << latest
* https://www.ladybug.tools/spider-gbxml-tools/spider-gbxml-viewer/

Web

* https://github.com/dohliam/dropin-minimal-css
* https://www.w3schools.com/w3css/
    * https://www.w3schools.com/w3css/w3css_colors.asp
    * https://www.w3schools.com/lib/w3-theme-red.css
* https://bootswatch.com/

Switching themes

* https://github.com/Mohammad-Farmaan/Dark-Mode-For-Web


## Change Log

### 2020-05-31 ~ Theo

* Cleanup
* Enhance read me files
* link to md help


### 2019-11-21 ~ Theo

omoh v 0.01.01

* R: Double quotes everywhere
* C: Add version meta tag
* C: Update readme

### 2019-01-06 ~ Theo

* First commit


***

# <center title="hello! go to top" ><a href=javascript:window.scrollTo(0,0); > ❦ </a></center>

