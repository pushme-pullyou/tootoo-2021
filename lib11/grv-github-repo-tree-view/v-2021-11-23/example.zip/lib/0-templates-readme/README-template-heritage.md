# [Template Read Me]( ./readme.html )

<!--@@@
<div style=height:300px;overflow:hidden;width:100%;resize:both; ><iframe src=https://heretics-sf.github.io/ height=100% width=100% ></iframe></div>
_Templatee_

### Full Screen: [Template]( https://heretics-sf.github.io/ )
@@@-->


## Concept


## To Do / Wish List


## Issues


## Links of Interest


## Change Log

### XXX

* First commit

***

<center><a href=javascript:window.scrollTo(0,0); class=aDingbat title="Scroll to top" > ❧ </a></center>

