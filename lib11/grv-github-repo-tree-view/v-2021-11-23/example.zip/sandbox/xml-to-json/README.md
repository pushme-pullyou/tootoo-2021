<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://ladybug.tools/spider-2020/sandbox/xml-to-json/readme.html "View file as a web page." ) </span>

<div><input type=button class = 'btn btn-secondary btn-sm' onclick=window.location.href="https://github.com/ladybug-tools/spider-2020/tree/master/sandbox/xml-to-json/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Spider XML to JSON Viewer Read Me]( ./readme.html )

<!--
<iframe src=https://ladybug.tools/spider-2020/sandbox/xml-to-json/ width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_basic-html.html_

### Full Screen: [Spider XML to JSON Viewer]( https://www.ladybug.tools/spider-2020/sandbox/xml-to-json/ )
-->

<details open >
<summary>Concept</summary>


</details>

<details open >
<summary>To do and wish list </summary>


</details>

<details open >
<summary>Issues </summary>


</details>

<details open >
<summary>Links of interest</summary>

The good start

* https://davidwalsh.name/convert-xml-json#:~:text=If%20you'd%20like%20the,XML%20and%20use%20JSON%20instead.

Very nice

* https://gist.github.com/chinchang/8106a82c56ad007e27b1

</details>

<details open >
<summary>Change log </summary>

### 123

* First commit

</details>

***

<center title="hello! Click me to go up to the top" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > <img width=24 src="https://ladybug.tools/artwork/icons_bugs/ico/spider.ico" > </a></center>

