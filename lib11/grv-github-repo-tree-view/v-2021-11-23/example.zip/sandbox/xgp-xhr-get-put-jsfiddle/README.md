<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://pushme-pullyou.github.io/tootoo-2021/sandbox/xgp-xhr-get-put-jsfiddle/readme.html  "View file as a web page." ) </span>

<div><input type=button onclick=window.top.location.href="https://github.com/pushme-pullyou/tootoo-2021/tree/master/sandbox/xgp-xhr-get-put-jsfiddle/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [xhr get put jsFiddle Read Me]( https://pushme-pullyou.github.io/tootoo-2021/sandbox/xgp-xhr-get-put-jsfiddle/readme.html )

<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/ sandbox/xgp-xhr-get-put-jsfiddle/ height=100% width=100% ></iframe></div>
_ZZZZZ in a resizable window. One finger to rotate. Two to zoom._

### Full Screen: [xhr get put jsFiddle]( https://pushme-pullyou.github.io/tootoo-2021/sandbox/xgp-xhr-get-put-jsfiddle/ )
@@@-->

* https://jsfiddle.net/theo/2azktLex/
* https://github.com/penge/my-notes/issues/182

## Concept


## To Do / Wish List


## Issues

* Using textare to contain the text. Would prefer DIV contentEditable, but this seems to have issues with 8-bit and 16-bit text converting

## Links of Interest


## Change Log


### 2021-02-11


* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
