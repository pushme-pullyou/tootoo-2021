# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [notesy Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#sandbox/notesy/README.md)


<!--@@@
<div style=	height:400px;overflow:hidden;resize:both;width:100%; ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/sandbox/notesy/ height=100% width=100% ></iframe></div>
_"notesy" in a resizable window. One finger to rotate. Two to zoom._

## Full Screen: [notesy]( https://pushme-pullyou.github.io/tootoo-2021/sandbox/notesy/ )
@@@-->


## Concept

* Edit files on GitHub
* Links to source for better editing tools


## To Do / Wish List

* Links to source on GitHub
* Links to vs code local files
* Figure out DOM parsing - going cleanly from innerText to innerHTML and back

## Issues


## Links of Interest

* https://github.com/beautify-web/js-beautify
* https://stackoverflow.com/questions/3913355/how-to-format-tidy-beautify-in-javascript

## Change Log


### 2021-07-21

* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
