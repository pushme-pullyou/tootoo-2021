<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://pushme-pullyou.github.io/tootoo-2021/lib/xgp-xhr-get-put/readme.html  "View file as a web page." ) </span>

<div><input type=button onclick=window.top.location.href="https://github.com/pushme-pullyou/tootoo-2021/tree/master/lib/xgp-xhr-get-put/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [XGP XHR get put Read Me]( https://pushme-pullyou.github.io/tootoo-2021/lib/xgp-xhr-get-put/readme.html )


### Full Screen: [XGP XHR get put]( https://pushme-pullyou.github.io/tootoo-2021/lib/xgp-xhr-get-put/ )


## Concept

use XMLHTTPRequest to GET or PUT any file in a GitHub repository


## To Do / Wish List

* Read and write to any repo on GitHub
* HTML file editor
* Embed in TooToo
* Google Drive to GitHub repo syn


## Issues


## Links of Interest

* https://github.com/penge/my-notes
* https://github.com/dropbox/dropbox-sdk-js
* https://github.com/github-tools/github

## Change Log

### 2021-02-12

* Many fixes

### 2021-01-23

* Bring together code from a lot of oldrr files
* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
