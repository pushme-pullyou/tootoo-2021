# FFP File Fetch Put Read Me


<details open >
<summary>Concept</summary>


</details>


<details>
<summary>To Do / Wish List</summary>


</details>


<details>
<summary>Issues</summary>


</details>


<details>
<summary>Change Log</summary>

### 2019-10-12 ~ Theo

* First commit

</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > ❦ </a></center>
