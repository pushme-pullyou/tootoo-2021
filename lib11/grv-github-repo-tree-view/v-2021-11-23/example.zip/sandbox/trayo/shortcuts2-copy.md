win10:<br>
* Keyboard shortcuts in Windows<br>
* dictation<br>
* darkmode: settings > personalization<br>
gMail:<br>
* keyboard shortcuts: ?<br>
* space bar: scroll preview<br>
* cursor keys: scroll messages<br>
<br>
chrome browser<br>
* help: F1<br>
* close tab: ctrl-w<br>
Jump to the next open tab: Ctrl + Tab or Ctrl + PgDn<br>
* caret browsing: F7<br>
* Open a new window in Incognito mode: Ctrl + Shift + n<br>
<br>
chromebook: blog<br>
* help: ctrl-alt-/<br>
* accessibility features - dictation<br>
<br>
vs code:<br>
* >> keyboard shortcuts: Ctrl + K Ctrl + R<br>
* Curser add select next: Ctrl + D<br>
* Cursor add below: alt-ctrl-↓<br>
* Definition: F12<br>
* Delete prev||next: ctrl + bspace||delete<br>
* Folding: ctrl-K-ctrl-1 || ctrl+shift+[||]<br>
* Search case|regex|whole word: Alt+C|R|W T<br>
* Selection expand: alt + shift + rArr<br>
* Settings json: ctrl + ,<br>
* Terminal: ctrl + `<br>
* Word wrap: alt + z<br>
Custom<br>
* Title Case: ctrl + i<br>
* home||end: alt + lArr||rArr<br>
emmet cheat-sheet<br>
* html:5<br>
* lorem100<br>
* ul>li.item$*5 << type this then press tab<br>
