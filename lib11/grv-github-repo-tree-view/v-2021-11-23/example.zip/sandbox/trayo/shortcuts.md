

win10:<br>
* <a href="https://support.microsoft.com/en-us/help/12445/windows-keyboard-shortcuts"
	target="_blank">Keyboard shortcuts in Windows</a><br>
* <a href="https://support.microsoft.com/en-us/help/4042244/windows-10-use-dictation"
	target="_blank">dictation</a><br>
* darkmode: settings > personalization<br>
</p>

<p>
gMail:<br>
* keyboard shortcuts: ?<br>
* space bar: scroll preview<br>
* cursor keys: scroll messages
<p>
<a href="https://support.google.com/chrome/answer/157179?hl=en" target="_blank">chrome browser</a><br>
* help: F1<br>
* close tab: ctrl-w<br>
Jump to the next open tab: Ctrl + Tab or Ctrl + PgDn<br>
* caret browsing: F7<br>
* Open a new window in Incognito mode: Ctrl + Shift + n
</p>
<p>
chromebook: <a href="https://blog.google/products/chromebooks/" target="_blank">blog</a><br>
</b>* help: ctrl-alt-/</b><br>
* <a href="https://support.google.com/chromebook/answer/177893?hl=en" target="_blank">accessibility
	features - dictation</a>
</p>
<p>
vs code:<br>
* >> <a href="https://code.visualstudio.com/shortcuts/keyboard-shortcuts-windows.pdf"
	target="_blank">keyboard shortcuts</a>: Ctrl + K Ctrl + R<br>
* Curser add select next: Ctrl + D<br>
* Cursor add below: alt-ctrl-&darr;<br>
* Definition: F12<br>
* Delete prev||next: ctrl + bspace||delete<br>
* Folding: ctrl-K-ctrl-1 || ctrl+shift+[||]<br>
* Search case|regex|whole word: Alt+C|R|W T <br>
* Selection expand: alt + shift + rArr<br>
* Settings json: ctrl + ,<br>
* Terminal: ctrl + `<br>
* Word wrap: alt + z<br>
Custom<br>
* Title Case: ctrl + i</br>
* home||end: alt + lArr||rArr<br>

</p>
<p>
<a href="https://docs.emmet.io/cheat-sheet/" target="_blank">emmet cheat-sheet</a><br>
* html:5<br>
* lorem100<br>
* ul>li.item$*5 << type this then press tab<br>
	* <br>
</p>
