<div><a href="https://www.google.com/collections/s/list/aC4sz9C4MSG7ImIoVgGN1w/pJGl3_zBt7I"
					target="_blank">google favorites</a></div>

<div><a href="https://www.30secondsofcode.org/js/p/1/" target="_blank">30secondsofcode</a></div>

<div><a href="https://www.30secondsofcode.org/css/p/1/" target="_blank">css.30secondsofcode</a>
			</div>

<div><a href="https://htmldom.dev/" target="_blank">htmldom.dev</a></div>

			<div><a href="https://dev.to/vasanthv/use-css-to-automatically-enable-dark-mode-in-your-web-app-based-on-system-settings-2jlp"
					target="_blank">CSS automatic enable dark mod</a></div>

			<div><a href="https://www.w3schools.com/colors/colors_names.asp"
					target="_blank">w3schools color names</a>~<a href="https://www.w3schools.com/colors/colors_groups.asp" target="_blank">groups</a>
			</div>

			<div><a href="https://html.spec.whatwg.org/multipage/named-characters.html#named-character-references"
					target="_blank">named character references all</a></div>

			<div><a href="https://simpl.info/" target="_blank">simple.info</a> try their CORS</div>



			<br>

			<div>
				<a href="https://zapier.com/learn/customer-support/improv-customer-support/" target="_blank">
				4 rules
					of
					improv</a>
				<button onclick=dia4rules.open=!dia4rules.open;>4r</button>

				<dialog id=dia4rules onclick=this.open=false;>
					<p>
						4 Rules of Improv
					</p>
					<div>
						Rule 1: Say Yes. The first rule of improvisation is AGREE. Always agree
						and SAY YES. ...
					</div>
					<div>
						Rule 2: Say Yes AND. The second rule of improvisation is not only to say
						yes, but YES, AND. ...
					</div>
					<div>
						Rule 3: Make Statements. The next rule is MAKE STATEMENTS. ...
					</div>
					<div>
						Rule 4: There Are No Mistakes. THERE ARE NO MISTAKES, only
						opportunities.
					</div>

				</dialog>
			</div>
