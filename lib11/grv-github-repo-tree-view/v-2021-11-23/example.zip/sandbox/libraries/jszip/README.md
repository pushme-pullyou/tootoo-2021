# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [jsZip Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#sandbox/libraries/jszip/README.md)


<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/sandbox/libraries/jszip/ height=100% width=100% ></iframe></div>
_"jsZip" in a resizable window. One finger to rotate. Two to zoom._
@@@-->

## Full Screen: [jsZip]( https://pushme-pullyou.github.io/tootoo-2021/sandbox/libraries/jszip/ )


## Concept

* Open and then convert a foldr of docx files with "theo" format into Markdown format
* Open a folder of Markdown files with th same name
* Combine the data in the two files into one file
* Convert the Markdown data to HTML
* Compress the files into a single zip file

## To Do / Wish List


## Issues


## Links of Interest


## Change Log


### 2021-11-01

* creates list of file names
()
* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
