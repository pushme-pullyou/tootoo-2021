<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page](https://theo-armour.github.io/2020/sandbox/bookmarklets/readme.html "View file as a web page.") </span>

<div><input type=button onclick=window.location.href="https://github.com/theo-armour/2020/"
value="You are now in a GitHub web page view - Click this button to view this read me file as source code" ></div>

# [Bookmarklets Read Me]( #README.md )

<!--
<div style=height:300px;overflow:hidden;width:100%;resize:both; ><iframe src=https://theo-armour.github.io/2020/ height=100% width=100% ></iframe></div>
_ZZZZZ_

### Full Screen: [Bookmarklets]( https://theo-armour.github.io/2020/sandbox/Bookmarklets )
-->


## Bookmarklets


<a href="javascript:window.scrollTo(0,0);" >^ go to top</a>

<a href="javascript:void(document.body.style.backgroundColor='#fee')">pink</a>

<a href="javascript:( () =>{document.body.style.backgroundColor='#fee';document.body.style.color='#0f0';} )()">pink&blue</a>

    <a href="javascript:( ()=>{document.body.style.backgroundColor='#fee';document.body.style.color='#0f0';} )()">pink&blue</a>


<a href="JavaScript:(() => { 
    doc=document,gtb=(ds)=>{if(getComputedStyle(ds,null).backgroundColor==='rgb(255, 255, 255)'){return true;} return false;},tmp=[];
    ['body','table','td','div','html','dl','ul','pre'].map(ta=>tmp.push(...Array.from(doc.getElementsByTagName(ta)).filter(gtb)));
    tmp.map(s=>s.style.backgroundColor='blue'; 
    } )()" >blue - not</a>

    
### Theme switching

Dropin

* https://github.com/ladybug-tools/spider-gbxml-tools/tree/master/spider-gbxml-viewer/v-2020-02-17/settings/theme-dropin/v-2020-01-17

Theme switch TA ~ W3schools ~ bootstrap

https://github.com/ladybug-tools/spider-gbxml-tools/tree/master/spider-gbxml-viewer/v-0-17-07/thm-theme






<a href=""></a>

<a href=""></a>

<a href=""></a>

### Older

<a href="JavaScript:void(doc=document,gtb=(ds)=>{if(getComputedStyle(ds,null).backgroundColor==='rgb(255, 255, 255)'){return true;} return false;},tmp=[];['body','table','td','div','html','dl','ul','pre'].map(ta=>tmp.push(...Array.from(doc.getElementsByTagName(ta)).filter(gtb)));tmp.map(s=>s.style.backgroundColor='blue';)" >blue - not</a>


<a href="data:text/html;charset=utf-8, <title>Scratchpad</title><style>body {padding: 5%; font-size: 1.5em; font-family: Arial; }"></style> <link rel="shortcut icon" href="https://ssl.gstatic.com/docs/documents/images/kix-favicon6.ico"/><body OnLoad='document.body.focus();' contenteditable spellcheck="true" >scratch pad</a>


<a href="data:text/html, <html contenteditable style='padding:10%;'>" >content edit</a>

<a href='javascript:(function(){
var e=[],t=document.getElementsByTagName("a"),n=t.length,r=window.open("","win","width=300,height=300");
for(;n>0;n--){var i=t[n-1].getAttribute("href");t[n-1]!=null&amp;&amp;i!=null&amp;&amp;i.charAt(0)==="h"&amp;
&amp;i.indexOf(window.location.hostname)==-1&amp;
&amp;e.push("<li><a href="+i+">"+i+"</a></li>")}r.document.open("text/html","replace"),r.document.write("<h1>Links Found:</h1><ul>"+e.join("")+"</ul>")})()'>Get all external Links</a>


Open new  pages easily - even with window location

<p><a href="https://theo-armour.github.io/snippets/bookmarklets/mozilla-text-editor.html" target="_blank">text edit</a></p>

<p><a href="javascript:(function(){document.body.contentEditable = true;})()" >make content editable</a></p>

<p><a href='javascript:(function(){window.open("http://jkirchartz.com/demos/HTML5notepad.html","HTML5 notepad");})()' >jkirchartz html5 notepad</a></p>

<p><a href='javascript:(function(){window.open("jkirchartz-demos/HTML5notepad.html","HTML5 notepad");})()' >html5 notepad local</a></p>

<p><a href="javascript:(function(){window.open('http://validator.w3.org/check?uri='+window.location);})()" >Validate with validator.w3.org</a></p>

<p><a href="javascript:(function(){window.open('data:text/html, <html contenteditable style=padding:10%; ></html>')})()" >open new editable page</a></p>


## 2020-06-27

* Fork to spider-2020


***

<center title="hello! Click me to go up to the top" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; >❦</a></center>
