<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://theo-armour.github.io/2021/sandbox/readme.html  "View file as a web page." ) </span>

<div><input type=button onclick=window.top.location.href="https://github.com/theo-armour/2021/tree/master/sandbox/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Sandbox Read Me]( https://theo-armour.github.io/2021/sandbox/readme.html )

<!--@@@
<div class=iframe-resize ><iframe src=https://theo-armour.github.io/2021/sandbox/us-county-votes/index.html  height=100% width=100% ></iframe></div>
_ZZZZZ in a resizable window. One finger to rotate. Two to zoom._

### Full Screen: [Sandbox]( https://theo-armour.github.io/2021/sandbox/us-county-votes/index.html )
@@@-->


## Concept

* Projects that are new and experimental and may or may not go anywhere

## To Do / Wish List


## Issues


## Links of Interest


## Change Log


### 2021-01-01

* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
