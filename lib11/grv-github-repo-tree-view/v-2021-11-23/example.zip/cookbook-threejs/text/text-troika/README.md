<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://jaanga.github.io/cookbook-threejs/examples/0-templates/ "View file as a web page." ) </span>


<div><input type=button onclick="window.location.href='https://github.com/jaanga/jaanga.github.io/tree/master/cookbook-threejs/0-templates/README.md'";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [ZZZZZ Read Me]( #xxxxxx/README.md )

<!--
<iframe src=https://jaanga.github.io/cookbook/examples/xxxxxx/xxxxxx.html width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_basic-html.html_

### Full Screen: [ZZZZZ]( https://jaanga.github.io/cookbook/examples/xxxxxx/xxxxxx.html )

-->

<details open >
<summary>Concept</summary>

* https://theo-armour.github.io/2020/journal/06/2020-06-18-brian/metro-area-stats-get-csvs.html

</details>

<details open >
<summary>To do and wish list </summary>


</details>


<details open >
<summary>Links of interest</summary>

* https://github.com/protectwise/troika
* https://github.com/protectwise/troika/tree/master/packages/troika-3d-text
* https://troika-examples.netlify.app/#text
* https://www.npmjs.com/package/troika-3d-text
* https://github.com/lojjic/aframe-troika-text
* `<script src="https://cdn.jsdelivr.net/npm/troika-three-utils@0.40.0"></script>`
* `<script src="https://cdn.jsdelivr.net/npm/troika-worker-utils@0.40.0"></script>`
* `<script src="https://cdn.jsdelivr.net/npm/troika-three-text@0.40.0"></script>`
* https://github.com/lojjic/aframe-troika-text
</details>

<details open >
<summary>Change log </summary>

### 2020-06-09

Want

* Double-sided text
* Instanced buffer geometry text
    * With matrix.compose

* First commit

</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > ❦ </a></center>
