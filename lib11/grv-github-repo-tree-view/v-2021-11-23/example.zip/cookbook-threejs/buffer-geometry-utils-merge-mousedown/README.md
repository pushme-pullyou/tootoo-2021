# intersects



* https://codesandbox.io/s/change-material-color-on-hover-hwmi0?file=/public/client.js
* https://threejs.org/examples/webgl_interactive_buffergeometry
* C:\Users\theo\Dropbox\Public\git-repos\spider-2020\spider-pollination-viewer\v-2021-08-12\pollination\pp-pollination-parse-2020-06-26.js