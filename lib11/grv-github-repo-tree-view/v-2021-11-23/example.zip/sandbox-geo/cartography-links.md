# Cartography Links


## trends

* https://www.npmtrends.com/cesium-vs-leaflet-vs-mapbox-gl-vs-three-js
* https://github.com/Leaflet/Leaflet/ leaflet.js
	* Github 29,800 stars ~ issues 432 open 4018 closed
	* StackOverflow 11,125 questions
OpenStreetMap
	* StackOverflow 3,646 questions
	* https://gis.stackexchange.com/questions/tagged/openstreetmap
Mapbox
	* StackOverflow 5,070 questions
Cesium
	* StackOverflow 685 questions
* https://github.com/tangrams/tangram ~ current
three.js
	* StackOverflow 17,018 questions
esri
	* StackOverflow 932 questions
* Observable
	* StackOverflow 8,030 questions
* OpenLayers
	* StackOverflow 4,241 questions
* https://www.osgeo.org/ osGeo

Compare

* https://www.geoapify.com/leaflet-vs-openlayers
* https://gis.stackexchange.com/questions/33918/choosing-openlayers-or-leaflet
* https://stackshare.io/stackups/google-maps-vs-leaflet-vs-mapbox


## Libraries

* https://3dmr.eu/
* https://cesium.com/
* https://deck.gl/
	* https://github.com/visgl/deck.gl/blob/master/docs/get-started/using-standalone.md
* https://www.esri.com/en-us/home
* https://www.f4map.com/
* https://kepler.gl/
* https://l7.antv.vision/en
* https://github.com/Leaflet/Leaflet
* https://www.mapbox.com/
	* https://www.mapbox.com/blog/
* https://mappa.js.org/
	* https://mappa.js.org/docs/examples-three-js.html
* https://maptalks.org/
	* 3,100 GH stars
* https://www.openglobus.org/
* https://osmbuildings.org/
* https://www.osgeo.org/
* https://openlayers.org/
	* https://giscience.github.io/GIScene.js/
		* update 2016 A 3D WebGIS framework. Based on Three.js. Easy to learn and customize.
* https://github.com/potree/potree/
	* https://github.com/pnext/three-loader
* https://github.com/tangrams/tangram
* https://terria.io/applications
* https://www.thunderforest.com/
* https://vis.gl/
* https://github.com/UDST/vizicities ~ 2016
* https://github.com/w3reality/three-geo
* https://www.wrld3d.com/
* https://worldwind.arc.nasa.gov/web/examples/#anchor


### OSGeo

* https://wiki.osgeo.org/wiki/Tile_Map_Service_Specification

## Google Tiles

* https://www.microimages.com/documentation/TechGuides/78googleMapsStruc.pdf
* https://www.maptiler.com/
* http://oms.wff.ch/calc.php?baseurl=cylce&lat=47.629000&long=7.262000&longto=7.906000&latto=47.354000
* https://www.researchgate.net/figure/Google-Maps-Tiling-Scheme-the-first-three-zoom-levels-the-tiles-and-their-numbering_fig1_321064657
* https://cfis.savagexi.com/2006/05/03/google-maps-deconstructed/


## OSM & Tile Servers

* https://www.openstreetmap.org/#map=17/49.43734/11.12898
* https://blog.openstreetmap.org/
* https://forum.openstreetmap.org/viewforum.php?id=42
* https://Help.openstreetmap.org
* https://lists.openstreetmap.org/listinfo


Wiki

* https://wiki.openstreetmap.org/wiki/Commercial_OSM_Software_and_Services
* https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames#Tile_servers
* https://wiki.openstreetmap.org/wiki/OSM-3D.org
* https://wiki.openstreetmap.org/wiki/List_of_OSM-based_services
* https://wiki.openstreetmap.org/wiki/TMS
* https://wiki.openstreetmap.org/wiki/Tiles

OSM Domains
* https://osmtools.de/osmlinks/
* https://healthsites.io/map#!/locality/node/2340008551
* https://maproulette.org/
* https://www.openstreetmap.us/
* https://osmus.civicrm.org/user/login?destination=civicrm/dashboard%3Freset%3D1
* http://fieldpapers.org/
* https://www.hotosm.org/


OSM Tools
* http://mc.bbbike.org/mc/ <<< map compare ****
* https://switch2osm.org/
* http://osm2world.org/
* https://github.com/vvoovv/blender-osm#openstreetmap-importer-for-blender
* http://osmgo.org/
* https://github.com/rastapasta/mapscii
* https://www.mapillary.com/


## https://leafletjs.com/ Leaflet.js

* https://leafletjs.com/
* https://github.com/Leaflet/Leaflet
* https://stackoverflow.com/questions/tagged/leaflet
* https://twitter.com/LeafletJS

### Leaflet users

* https://osmbuildings.org/
* https://www.wrld3d.com/ ~ $$$


### Leaflet + Three.js

* http://geommills.github.io/esrileaflet3JS/
	* 2015 ~ 2d & 3d ~ no 3d Terrain ~ esri / leaflet
	* Creates a large JPG uses as texture
* https://mappa.js.org/
	* Three.js as a layer over Leaflet
	* https://jsfiddle.net/hg474d6r/7/
* https://mocainfo.thm.de/building-3d/
	* Adds a Three.js layer of 3D buildings over Leaflet map
	* http://bl.ocks.org/Sumbera/c6fed35c377a46ff74c3
* https://github.com/UDST/vizicities
	* 2016 ~ lots of features ~ complex ui


### Leaflet + Three.js + 3D Globe

* http://www.webglearth.com/#ll=0.00000,0.00000;alt=17000000
* http://examples.webglearth.com/


## MapBox

public access token
* pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg

Sites
* https://en.wikipedia.org/wiki/Mapbox
* https://www.mapbox.com/
* https://twitter.com/Mapbox
* https://www.linkedin.com/company/mapbox/
* https://www.crunchbase.com/organization/mapbox/people
* https://www.instagram.com/mapbox/?hl=en
* https://www.mapbox.com/blog?utm_campaign=medium_notice_2020
* https://wiki.openstreetmap.org/wiki/Mapbox
* https://www.youtube.com/channel/UCIHl9sd2brgvjBlSETKYDcg
* https://www.mapbox.com/community/
* https://docs.mapbox.com/help/

Docs
* https://github.com/mapbox
* https://docs.mapbox.com/help/how-mapbox-works/web-apps/
* https://docs.mapbox.com/mapbox-gl-js/api/

Stackoverflow

* https://stackoverflow.com/questions/tagged/mapbox


## Forks

* https://carto.com/developers/mapbox/guides/getting-started/
* https://maptalks.org/
	* Uses mapbox
	* https://maptalks.org/maptalks.three/demo/index.html
* https://github.com/peterqliu/threebox
	* 2019
	* https://codepen.io/MannyMeadows/pen/qoZWEM
* https://github.com/w3reality/three-geo
	* Mapbox + three.js

## Articles

* https://www.forbes.com/sites/bizcarson/2018/05/08/mapbox-maps-developers/?sh=50b6a681164d
* https://www.codementor.io/@victorgerardtemprano/pros-and-cons-of-using-mapbox-for-your-project-dx04pfgxw

## mourner agafonkin

* https://observablehq.com/@mourner
* https://observablehq.com/search?page=2&query=three.js

### planet textures

* https://www.solarsystemscope.com/textures/

### Stackoverflow

* https://stackoverflow.com/questions/17682551/three-js-leaflet-3d-maps
* https://stackoverflow.com/questions/38339961/how-to-put-a-mapboxgl-map-in-three-js-without-requiring-two-canvases'
* https://stackoverflow.com/questions/25559222/leaflet-osm-tiles-shown-as-a-ground-plane-in-a-2d-environment
* https://stackoverflow.com/questions/60075700/three-js-positionning-objects-according-their-coordinates
* https://stackoverflow.com/questions/45805193/three-js-layer-for-leaflet/47200362#47200362
* https://stackoverflow.com/questions/16830824/google-maps-using-three-js-and-webgl/27653983#27653983
* https://stackoverflow.com/questions/59733455/location-based-ar-with-three-js-react-camera-configuration/60265551#60265551
* https://stackoverflow.com/questions/59733455/location-based-ar-with-three-js-react-camera-configuration/60265551#60265551


## Articles

* https://www.reddit.com/r/openstreetmap/comments/6isju5/openstreetmap_websitesapps_to_share/
* https://webkid.io/blog/3d-map-library-roundup/
* https://blog.mapbox.com/bringing-3d-terrain-to-the-browser-with-three-js-410068138357
* https://github.com/sshuair/awesome-gis
* http://science.geof.unizg.hr/cmc2018/wp-content/uploads/2019/10/Proceedings_ICA_11CMC.pdf
* https://bachasoftware.com/custom-software-development/
* https://dev.to/camptocamp-geo/the-3-best-open-source-web-mapping-libraries-57o7


## Associations

* http://www.mountaincartography.org/
* https://icaci.org/category/commission-news/commission-on-mountain-cartography/
* https://geohipster.com/

## Twitter

* https://twitter.com/thematicmapping


## Symbols and themes

* https://wiki.gis.com/wiki/index.php/Proportional_symbol_map
>A Proportional symbol map is a type of Thematic map that uses map symbols that vary in size to represent a quantitative variable. [1]Symbols vary in height, length, area, or volume from place to place depending on the variable that they represent. [2] For example, discs may be used to show the location of cities within the map where the size of the disc is proportional to the population of the city.
>This type of map is useful for visualization when raw data cannot be dealt with as a ratio or proportion. Although circles are the most typical symbol because they are more compact due to their low perimeter to area ratio, studies show that it is easier for the reader to estimate the size of the symbol if it is a square or a bar. [3] The best way to increase the reader's ability to correctly estimate the size of a circle is through effective legend design, including providing examples of different sized circles which will be shown in the map. Proportional symbol maps are effective because they allow the reader to understand large quantities of data in a fast and simple way.
* http://resources.arcgis.com/en/help/main/10.1/index.html#//00s500000005000000
* https://pro.arcgis.com/en/pro-app/latest/help/mapping/layer-properties/proportional-symbology.htm
* https://blog.mastermaps.com/2008/06/proportional-symbols-in-three.html
* http://thematicmapping.org/engine/
* https://www.tableau.com/learn/articles/data-visualization/glossary



## MapBox

https://api.mapbox.com/v4/mapbox.terrain-rgb/15/5242/12663.pngraw?access_token=pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg

https://api.mapbox.com/v4/mapbox.terrain-rgb/0/0/0.pngraw?access_token=pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg

https://api.mapbox.com/v4/mapbox.terrain-rgb/7/20/49.pngraw?access_token=pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg


height = -10000 + ((R * 256 * 256 + G * 256 + B) * 0.1)

key from https://www.mapbox.com/mapbox-gl-js/example/map-tiles/

http://a.tiles.mapbox.com/v4/mapbox.mapbox-streets-v6/14/4823/6160.vector.pbf?access_token=pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg

works!!!

pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg

https://api.mapbox.com/v4/mapbox.streets/14/4823/6160.png?access_token=pk.eyJ1IjoidGhlb2EiLCJhIjoiY2o1YXFra3V2MGIzbzJxb2lneDUzaWhtZyJ9.7bYFAQabMXiYmcqW8NLfwg


http://tile.openstreetmap.org/7/20/49.png




## Google Maps

Google Maps Time Zone API
* https://developers.google.com/maps/documentation/timezone/start
* https://maps.googleapis.com/maps/api/timezone/json?location=38.908133,-77.047119&timestamp=1458000000
* https://stackoverflow.com/questions/23017766/google-maps-tile-url-for-hybrid-maptype-tiles

>Smart clients were supposed to spread the load across servers mt0 to mt3. But now, these names and mt are all aliases (CNAMEs) of mt.l.google.com that the DNS rotates through a number of addresses as it is queried. So, simply using mt.google.com will do the balancing globally, and locally if you do multiple DNS queries

h = roads only ~ white background
m = standard road map
p = terrain ~ all black
r = somehow altered road map ~ nothing visible
s = satellite only
t = terrain only
y = hybrid

