# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [Topo JSON Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#sandbox-maps/topojson/README.md )


<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/ xxxxx/ height=100% width=100% ></iframe></div>
_ Topo JSON in a resizable window. One finger to rotate. Two to zoom._


### Full Screen: [Topo JSON]( https://pushme-pullyou.github.io/tootoo-2021/xxxxx/ )
@@@-->


## Concept


## To Do / Wish List


## Issues


## Links of Interest

No updates since 2017

TopoJSON

* https://github.com/topojson/topojson
* https://github.com/topojson/topojson-specification/blob/master/README.md
* https://en.wikipedia.org/wiki/GeoJSON#TopoJSON


LatLon to TJ
* https://stackoverflow.com/questions/38270132/topojson-d3-map-with-longitude-latitude

TopJson to TThree.js

* https://stackoverflow.com/questions/57743270/how-can-i-display-topojson-with-three-js-basic

## Change Log


### 2021-07-10

* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
