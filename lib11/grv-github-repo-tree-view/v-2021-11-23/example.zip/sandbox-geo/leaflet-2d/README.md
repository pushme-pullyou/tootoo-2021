<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://pushme-pullyou.github.io/cookbook.leaflet-2d/xxxxx/  "View file as a web page." ) </span>



# [Leaflet 2D Read Me]( ./index.html )

<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/cookbook.leaflet-2d/ height=100% width=100% ></iframe></div>
_Leaflet 2D_

### Full Screen: [Leaflet 2D]( https://pushme-pullyou.github.io/cookbook.leaflet-2d/ )
@@@-->


## Concept


## To Do / Wish List


## Issues


## Links of Interest


## Change Log

### 2021-01-08

* First commit


***

<center><a href=javascript:window.scrollTo(0,0); class=aDingbat title="Scroll to top" > ❦ </a></center>
