https://eric.clst.org/tech/usgeojson/
