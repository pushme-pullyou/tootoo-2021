# CSV

## JHU

* https://github.com/CSSEGISandData/COVID-19/blob/master/csse_covid_19_data/UID_ISO_FIPS_LookUp_Table.csv
* https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/UID_ISO_FIPS_LookUp_Table.csv
* Updated daily
* Provides FIPS & othedr IDa
* Lat, Lon, population
* The best so far

## Wiki

* https://en.wikipedia.org/wiki/FIPS_county_code

## US Census

* https://www.census.gov/geographies/reference-files/2020/demo/popest/2020-fips.html

