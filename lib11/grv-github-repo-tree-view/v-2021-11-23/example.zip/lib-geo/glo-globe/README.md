# [GLO Globe Read Me]( ./readme.html )

<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/lib-geo/glo-globe/ height=100% width=100% ></iframe></div>
_GLO Globe_

### Full Screen: [GLO Globe]( https://pushme-pullyou.github.io/tootoo-2021/lib-geo/glo-globe/ )
@@@-->


## Concept


## To Do / Wish List

* HTML file to use THR module
* Add scale to elevation 3D method

## Issues


## Links of Interest


## Change Log

### 2021-07-11

* update readme

### 2020-12-24

* First commit README.md
* Fork bitmaps to lib3d
* Add time stamps

<center><a href=javascript:window.scrollTo(0,0); class=aDingbat title="Scroll to top" > ❦ </a></center>
