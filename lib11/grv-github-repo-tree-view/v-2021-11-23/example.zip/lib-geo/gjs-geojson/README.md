# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [GJS geoJSON Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#lib-geo/gjs-geojson/README.md)


<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/lib-geo/gjs-geojson/ height=100% width=100% ></iframe></div>
_GJS GeoJSON_

### Full Screen: [GJS GeoJSON]( https://pushme-pullyou.github.io/tootoo-2021/lib-geo/gjs-geojson/ )
@@@-->


## Concept

* Open geoJSON file and display in 3D

## To Do / Wish List


## Issues


## Links of Interest


## Change Log

### 2021-07-11

* update readme

### 2020-12-16

* Fixed long-standing multiple polygon issue. Yay


***

<center><a href=javascript:window.scrollTo(0,0); class=aDingbat title="Scroll to top" > ❦ </a></center>
