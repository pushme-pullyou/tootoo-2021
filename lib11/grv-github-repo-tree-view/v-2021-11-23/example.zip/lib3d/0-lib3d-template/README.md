<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://ladybug.tools/spider-2020/spider-template-viewer/readme.html "View file as a web page." ) </span>

<div><input type=button class = 'btn btn-secondary btn-sm' onclick=window.location.href="https://github.com/ladybug-tools/spider-2020/tree/master/spider-template-viewer/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Spider Template Viewer Read Me]( ./readme.html )

_This is an actual read me. See ```assets/``` for a read me template_ 

<!--@@@
<iframe src=https://ladybug.tools/spider-2020/spider-template-viewer/ width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_Spider Template Viewer _
@@@-->

### Full Screen: [Spider Template Viewer]( https://www.ladybug.tools/spider-2020/spider-template-viewer/ )


<details open >
<summary>Concept</summary>


</details>

<details open >
<summary>To do and wish list </summary>

* Real EPW viewer
* Add viewer capability

</details>

<details open >
<summary>Issues </summary>

* Fog has issues
* Heart has issues

</details>

<details open >
<summary>Links of interest</summary>


</details>

<details open >
<summary>Change log </summary>

### 2020-06-09

* First commit

</details>

***

<center title="hello! Click me to go up to the top" ><a href=javascript:window.scrollTo(0,0); > <img width=24 src="https://ladybug.tools/artwork/icons_bugs/ico/spider.ico" > </a></center>

