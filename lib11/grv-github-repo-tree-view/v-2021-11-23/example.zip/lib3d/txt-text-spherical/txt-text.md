

## Objects as function parameters

* https://stackoverflow.com/questions/27735855/javascript-function-with-optional-parameters-as-object
	* function loadMap({latitude = "x.xxxx", longitude = "-x.xxxx"} = {})
	
## Olympic colors

* https://www.olympic.org/olympic-rings
* https://en.wikipedia.org/wiki/Olympic_symbols
* https://www.schemecolor.com/olympic-logos-and-symbols-colors.php

BLUE
Name: Blue (NCS)
Hex: #0085C7
RGB: (0, 133, 199)
CMYK: 1, 0.331, 0, 0.219

GOLDEN POPPY
Name: Golden Poppy
Hex: #F4C300
RGB: (244, 195, 0)
CMYK: 0, 0.200, 1, 0.043

BLACK
Name: Black
Hex: #000000
RGB: (0, 0, 0)
CMYK: NAN, NAN, NAN, 1

GREEN (PANTONE)
Name: Green (Pantone)
Hex: #009F3D
RGB: (0, 159, 61)
CMYK: 1, 0, 0.616, 0.376

Blue: Europe
Yellow: Asia
Black: Africa
Green: Oceania
Red: The Americas