<span style=display:none; >  <a href="https://ladybug-tools.github.io/spider-2020/lib/thr-three/" title="View file as a web page.">You are now in a GitHub source code view - click this link to view Read Me file as a web page</a> </span>

<div><input type=button onclick=window.top.location.href="https://github.com/ladybug-tools/spider-2020/blob/master/lib/thr-three/README.md" value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [THR Three Read Me]( https://www.ladybug.tools/spider-2020/lib/thr-three/readme.html )

<!--@@@
<iframe src=https://www.ladybug.tools/spider-2020/lib/thr-three/ class=iframe-resize ></iframe></div>
_THR Three in a resizable window. One finger to rotate. Two to zoom._

### Full Screen: [THR Three]( https://www.ladybug.tools/spider-2020/lib/thr-three/ )
@@@-->


## Concept


## To Do / Wish List

* 2020-07-17 ~ Axes helper to a toggle
* 2020-07-17 ~ Ground to a toggle

## Issues

* 2020-07-17 ~ Should axes, ground and lights be here or in a separate module?


## Links of Interest


## Change Log


### 2020-07-17 ~ Theo

thr-three-2020-07-17.js

* First commit this read me
* Fix resizing issues


***

<center title="hello! Click me to go up to the top" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > <img width=24 src="https://ladybug.tools/artwork/icons_bugs/ico/spider.ico" > </a></center>

