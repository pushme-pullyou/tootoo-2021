# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [Text Editor Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#cookbook/ted-text-edit/README.md)


<div style=height:510px;width:100%;resize:both; ><iframe src="https://pushme-pullyou.github.io/tootoo-2021/cookbook/ted-text-edit/" style=height:100%;width:100%; ></iframe></div>

## Full screen: [ Text Editor Theo ]( https://pushme-pullyou.github.io/tootoo-2021/cookbook/ted-text-edit/ )

## Wish list

* Format HTML
* Add insert image? Other Midas commands?

## Links

* https://www-archive.mozilla.org/editor/midasdemo/
* https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Editable_content
* https://developer.mozilla.org/en-US/docs/Mozilla/Projects/Midas

***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>