<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://theo-armour.github.io/2020/cookbook/toggle-drak-mode/readme.html  "View file as a web page." ) </span>

<div><input type=button onclick=window.top.location.href="https://github.com/theo-armour/2020/tree/master/cookbook/toggle-drak-mode/";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Toggle Dark Mode Read Me]( https://theo-armour.github.io/2020/cookbook/toggle-drak-mode/readme.html )

<!--@@@
<div style=height:500px;overflow:hidden;width:100%;resize:both; ><iframe src=https://theo-armour.github.io/2020/cookbook/toggle-drak-mode/ height=100% width=100% ></iframe></div>
_Toggle Dark Mode in a resizable window. One finger to rotate. Two to zoom._

### Full Screen: [Toggle Dark Mode]( https://theo-armour.github.io/2020/cookbook/toggle-drak-mode/ )
@@@-->


## Concept


## To Do / Wish List


## Issues


## Links of Interest

* https://dev.to/ananyaneogi/create-a-dark-light-mode-switch-with-css-variables-34l8
	* looks good
* https://dev.to/dcodeyt/add-dark-mode-to-your-websites-with-css-5bh4
	* https://codepen.io/dcode-software/pen/ZEQMEjG
* https://dev.to/mohammadfarmaan/the-best-way-to-dark-mode-your-website-1g7f
	* https://mohammad-farmaan.github.io/Dark-Mode-For-Web/
* https://dev.to/albertomontalesi/add-dark-mode-to-your-website-with-just-a-few-lines-of-code-5baf
	* >>>> document.addEventListener('DOMContentLoaded', () => { !!!

OS

* https://dev.to/blacksonic/add-dark-mode-to-your-site-with-this-short-css-trick-1g7b

## Change Log


### 2020-07-25

* First commit


***

<center title="hello! Click me to go up to the top" ><a href=javascript:window.scrollTo(0,0); style=font-size:2ch;text-decoration:none; > ❦ </a></center>
