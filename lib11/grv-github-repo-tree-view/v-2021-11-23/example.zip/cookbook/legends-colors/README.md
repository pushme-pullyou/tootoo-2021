# [![](https://pushme-pullyou.github.io/tootoo-2021/lib/assets/icons/mark-github.svg )](https://github.com/pushme-pullyou/tootoo-2021/ "Source code on GitHub" ) [TT 2021]( https://pushme-pullyou.github.io/tootoo-2021/ "Home page" ) / [Legend Colors Read Me]( https://pushme-pullyou.github.io/tootoo-2021/#cookbook/legends-colors/README.md)


<!--@@@
<div class=iframe-resize ><iframe src=https://pushme-pullyou.github.io/tootoo-2021/ cookbook/legends-colors/ height=100% width=100% ></iframe></div>
_"Legend Colors" in a resizable window. One finger to rotate. Two to zoom._
@@@-->

## Full Screen: [Legend Colors]( https://pushme-pullyou.github.io/tootoo-2021/cookbook/legends-colors/ )


## Concept


## To Do / Wish List


## Issues


## Links of Interest

* https://www.fabiocrameri.ch/colourmaps/
* https://docs.generic-mapping-tools.org/6.2/cookbook/cpts.html#cpt-files-a
* https://www.ladybug.tools/ladybug/docs/ladybug.color.html
* https://www.ladybug.tools/ladybug/docs/_modules/ladybug/color.html#Colorset

## Change Log


### 123

* First commit


***

<center title="Hello! Click me to go up to the top" ><a class=aDingbat href=javascript:window.scrollTo(0,0);> ❦ </a></center>
