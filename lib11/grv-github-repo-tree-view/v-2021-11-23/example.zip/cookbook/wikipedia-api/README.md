<span style=display:none; >[You are now in a GitHub source code view - click this link to view Read Me file as a web page]( https://www.ladybug.tools/spider-covid-19-viz-3d/sandbox/wikipdia-api/readme.html#assets/0-templates/README.md "View file as a web page." ) </span>

<div><input type=button class = 'btn btn-secondary btn-sm' onclick=window.location.href="https://github.com/ladybug-tools/spider-covid-19-viz-3d/tree/master/sandbox/wikipedia-api";
value='You are now in a GitHub web page view - Click this button to view this read me file as source code' ></div>


# [Wikipedia API Read Me]( https://www.ladybug.tools/spider-covid-19-viz-3d/readme.html#assets/0-templates/README.md/README.md )

<!--
<iframe src=https://pushme-pullyou.github.io/ width=100% height=500px >Iframes are not viewable in GitHub source code view</iframe>
_basic-html.html_

### Full Screen: [ZZZZZ]( https://www.ladybug.tools/spider-covid-19-viz-3d//xxxxxx/xxxxxx.html )
-->

<details open >
<summary>Concept</summary>


</details>

<details open >
<summary>To do and wish list </summary>


</details>

<details open >
<summary>Issues </summary>


</details>

<details open >
<summary>Links of interest</summary>

## wikipedia api

* https://en.wikipedia.org/w/api.php
* https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/en.wikipedia/all-access/user/Africa/daily/2017042700/201805170
	* https://medium.com/@mustaphamekhatria/get-wikipedia-pages-views-data-with-nodejs-54a265e0a78c

wiki geography

* https://en.wikipedia.org/wiki/List_of_countries_by_population_(United_Nations)
* https://en.wikipedia.org/wiki/List_of_sovereign_states
* https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population
* https://en.wikipedia.org/wiki/2019%E2%80%9320_coronavirus_pandemic_by_country_and_territory
* https://en.wikipedia.org/wiki/2020_coronavirus_pandemic_in_the_United_States

## Sustainable Development Goals

* https://sdgs.un.org/goals
* https://en.wikipedia.org/wiki/List_of_Sustainable_Development_Goal_targets_and_indicators
* https://www.cfr.org/backgrounder/sustainable-development-goals


### About

* https://www.futurelearn.com/info/courses/achieving-sustainable-development/0/steps/35496
* https://www.researchgate.net/publication/320291340_A_Critical_Analysis_of_the_Sustainable_Development_Goals
* https://www.weforum.org/agenda/2017/01/turns-out-sdg-critics-were-wrong/

### Me

* Where is the beauty?
* Where is the security?
* Where are the useful tags?
* Where is aging?
* Where are the ongoing metrics?
* Links to UN Declaration of human rights?

## JHU

* https://github.com/CSSEGISandData/COVID-19/blob/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv
	* Has lat & lon

### tests

* https://en.wikipedia.org/w/api.php?action=parse&format=json&origin=*&section=1&page=2019–20_coronavirus_pandemic_by_country_and_territory

</details>

<details open >
<summary>Change log </summary>

### 2020-04-08 ~ Theo

* First commit
* Using testQuery: It looks like loading a full article is much faster than asking just to load a single section


</details>

***

# <center title="hello!" ><a href=javascript:window.scrollTo(0,0); style=text-decoration:none; > <img src="../../assets/spider.ico" height=24 > </a></center>
